package software;

import java.util.*;
public class FactoryDemo {
	public static void main(String[]args) {
		ShapeFactory ft = new ShapeFactory();
		Shape a = ft.getConcreteShape("Circle");
		Shape b = ft.getConcreteShape("Square");
		Shape c = ft.getConcreteShape("Rectangle");
		a.draw();
		b.draw();
		c.draw();
	}
}

interface Shape {
	public void draw();
}

class Rectangle implements Shape{
	public void draw() {
		System.out.println("i am drawing rectangle");
	}
}

class Square implements Shape{
	public void draw() {
		System.out.println("i am drawing square");
	}
}

class Circle implements Shape{
	public void draw() {
		System.out.println("i am drawing circle");
	}
}

class ShapeFactory{
	Shape getConcreteShape(String s) {
		if(s.equalsIgnoreCase("Rectangle")) {
			return new Rectangle();
		}
		else if(s.equalsIgnoreCase("Square")) {
			return new Square();
		}
		else if(s.equalsIgnoreCase("Circle")) {
			return new Circle();
		}
		else return null;
	}
}