#include<iostream>
#include<string>
using namespace std;
class person
{
public:
    friend class List;
    person(void)
    {
        next=NULL;
        ptr=NULL;
    }
    person(string a,int b,string c,string d)
    {
        name=a;
        age=b;
        add=c;
        tele=d;
    }
    virtual void print(void)
    {
        cout<<"name:"<<name<<endl;
        cout<<"age:"<<age<<endl;
        cout<<"address:"<<add<<endl;
        cout<<"telephone number:"<<tele<<endl<<endl<<endl;
    }
    virtual person *getnext(void)
    {
        return next;
    }
protected:
    person *next;
    person *ptr;
    string name;
    string add;
    string tele;
    int age;
};
class student:public person
{
public:
    friend class List;
    student(string a,int b,string c,string d,float e,int f)
    {
        averagepoint=e;
        level=f;
        name=a;
        age=b;
        add=c;
        tele=d;
    }
    void print(void)
    {
        cout<<"name:"<<name<<endl;
        cout<<"age:"<<age<<endl;
        cout<<"address:"<<add<<endl;
        cout<<"telephone number:"<<tele<<endl;
        cout<<"grade point average:"<<averagepoint<<endl;
        cout<<"level:"<<level<<endl<<endl<<endl;
    }
protected:
    student *ptr;
    float averagepoint;
    int level;
};
class teacher:public person
{
public:
    friend class List;
    teacher(string a,int b,string c,string d,float e)
    {
        salary=e;
        name=a;
        age=b;
        add=c;
        tele=d;
    }
    void print(void)
    {
        cout<<"name:"<<name<<endl;
        cout<<"age:"<<age<<endl;
        cout<<"address:"<<add<<endl;
        cout<<"telephone number:"<<tele<<endl;
        cout<<"salary:"<<salary<<endl<<endl<<endl;
    }
protected:
    teacher *ptr;
    float salary;
};
class staff:public person
{
public:
    staff(string a,int b,string c,string d,float e)
    {
        wage=e;
        name=a;
        age=b;
        add=c;
        tele=d;
    }
    void print(void)
    {
        cout<<"name:"<<name<<endl;
        cout<<"age:"<<age<<endl;
        cout<<"address:"<<add<<endl;
        cout<<"telephone number:"<<tele<<endl;
        cout<<"hourly-wage:"<<wage<<endl<<endl<<endl;
    }
protected:
    staff *ptr;
    float wage;
};
class List
{
public:
    List(void)
    {
        head=NULL;
        now=NULL;
    }
    void insert(person *a)
    {
        if(head==NULL)
        {
            head=a;
        }
        else
        {
            now->next=a;
        }
        now=a;
    }
    person* get_head(void)
    {
        return head;
    }
private:
    person *head;
    person *now;
};
int main(void)
{
    staff A("chenling",40,"qingdao","0532324535-106",10);
    teacher B("liming",35,"beijing","0105918695-106",560.5);
    student C("liuying",20,"shanghai","03578395-456",80,3);
    student D("wanger",18,"shanghai","0334534535-496",10,1);
    List S;
    S.insert(&A);
    S.insert(&B);
    S.insert(&C);
    S.insert(&D);
    person *opp=S.get_head();
    while(opp!=NULL)
    {
        opp->print();
        opp=opp->getnext();
    }
}
