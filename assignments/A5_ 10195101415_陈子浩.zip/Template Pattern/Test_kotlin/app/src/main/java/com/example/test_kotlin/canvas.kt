package com.example.test_kotlin

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.widget.Toast

class Mycanvas(context: Context, attrs: AttributeSet):View(context,attrs){
    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        val xr=135F         //棋盘右偏移
        val yd=247F         //棋盘下偏移
        if(snake.life) {
            drawBoard(canvas, xr, yd)
            drawsnake(canvas, snake, xr, yd)
            drawfood(canvas, snake, xr, yd)
        }
        else
        {
            drawend(canvas,snake)
        }
    }


    override fun postInvalidate() {
        super.postInvalidate()
    }
    private fun drawBoard(canvas: Canvas?,xr:Float,yd:Float){
        if (canvas == null) {
            return
        }
        canvas.drawColor(Color.WHITE)
        val paint= Paint()
        paint.color=Color.BLACK
        for(i in 0..20)
        {
            val x=i*40F
            canvas.drawLine(x+xr,0F+yd,x+xr,800F+yd,paint)
            val y=i*40F
            canvas.drawLine(0F+xr,y+yd,800F+xr,y+yd,paint)
        }
    }

    private fun lightblock(canvas: Canvas?,xr:Float,yd:Float,x:Int,y:Int,color:Int){
        if (canvas == null) {
            return
        }
        val paint= Paint()
        paint.color=color
        canvas.drawRect(xr+x*40,yd+y*40,xr+x*40+40,yd+y*40+40,paint)
    }

    private fun drawsnake(canvas: Canvas?,snake:Snake,xr:Float,yd:Float){
        for(i in snake.body){
            lightblock(canvas,xr,yd,i.x,i.y,Color.GRAY)
        }
        lightblock(canvas,xr,yd,snake.head.x,snake.head.y,Color.BLACK)
    }

    private fun drawfood(canvas: Canvas?,snake:Snake,xr:Float,yd:Float){
        for(i in snake.foodgroup){
            lightblock(canvas,xr,yd,i.x,i.y,Color.RED)
        }
        lightblock(canvas,xr,yd,snake.head.x,snake.head.y,Color.BLACK)
    }

    private fun drawend(canvas: Canvas?,snake:Snake){
        if (canvas == null) {
            return
        }
        var paint=Paint()
        paint.color=Color.RED
        paint.alpha=255
        paint.textSize=250f
        canvas.drawText("你挂了",150f,500f,paint)
    }
}