package com.example.test_kotlin

import android.content.Intent
import android.graphics.Canvas
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock.sleep
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

var snake=Snake()
class Activity3 : AppCompatActivity(),View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_3)
        val button1: Button = findViewById(R.id.button4)
        button1.setOnClickListener(this)
        val button2: ImageButton = findViewById(R.id.up)
        button2.setOnClickListener(this)
        val button3: ImageButton = findViewById(R.id.down)
        button3.setOnClickListener(this)
        val button4: ImageButton = findViewById(R.id.left)
        button4.setOnClickListener(this)
        val button5: ImageButton = findViewById(R.id.right)
        button5.setOnClickListener(this)
        val button6: Button = findViewById(R.id.button6)
        button6.setOnClickListener(this)
        GlobalScope.launch {
            refresh()
        }
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.button4->{
                GlobalScope.cancel()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            R.id.button6->{
                snake=Snake()
            }
            R.id.left->{
                snake.direction="left"
            }
            R.id.right->{
                snake.direction="right"
            }
            R.id.up->{
                snake.direction="up"
            }
            R.id.down->{
                snake.direction="down"
            }
        }
    }

    private fun refresh(){
        while(true) {
            sleep(500)
            snake.move()
            val canva: View = findViewById(R.id.canvas)
            canva.postInvalidate()
        }
    }
}