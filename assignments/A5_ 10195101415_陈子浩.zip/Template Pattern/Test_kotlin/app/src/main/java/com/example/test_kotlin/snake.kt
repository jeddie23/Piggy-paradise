package com.example.test_kotlin

import java.lang.Math.random

class Snake(){
    var body:MutableList<Point> = mutableListOf(Point(6,10),Point(7,10),Point(8,10),Point(9,10))
    var head:Point=Point(10,10)
    var length=4
    var direction="right"
    var foodflag=false
    var foodgroup:MutableList<Point> = mutableListOf()
    var life=true

    fun move(){
        collision()
        if(life) {
            addfood()
            if (direction == "left") {
                body.add(length, Point(head.x, head.y))
                head.x = head.x - 1
            } else if (direction == "right") {
                body.add(length, Point(head.x, head.y))
                head.x = head.x + 1
            } else if (direction == "up") {
                body.add(length, Point(head.x, head.y))
                head.y = head.y - 1
            } else if (direction == "down") {
                body.add(length, Point(head.x, head.y))
                head.y = head.y + 1
            }
            collision()
            if (foodflag == false) {
                body.removeAt(0)
            }
            foodflag = false
        }
    }

    fun collision(){
        var countn=0
        var eatnum=9
        for(i in foodgroup){
            if((i.x==head.x)&&(i.y==head.y)){
                foodflag=true
                eatnum=countn
                length=length+1
            }
            countn=countn+1
        }
        if(eatnum!=9) {
            foodgroup.removeAt(eatnum)
            addfood()
        }
        for(i in body){
            if((i.x==head.x)&&(i.y==head.y))
            {
                life=false
                break
            }
        }
        if((head.x>19)||(head.x<0)) {
            life = false
        }
        if((head.y>19)||(head.y<0)) {
            life = false
        }
    }

    fun addfood(){
        while(true){
            if(foodgroup.count()<3){
                var newfood=Point((0..19).random(),(0..19).random())
                var c=false
                for(i in foodgroup){
                    if((i.x==newfood.x)&&(i.y==newfood.y)){
                        c=true
                    }
                }
                for(i in body){
                    if((i.x==newfood.x)&&(i.y==newfood.y)){
                        c=true
                    }
                }
                if((head.x==newfood.x)&&(head.y==newfood.y)){
                    c=true
                }
                if(c==false)
                {
                    foodgroup.add(newfood)
                }
            }
            else{
                break
            }
        }
    }
}

class Point(a:Int,b:Int){
    var x=0
    var y=0
    init {
        x=a
        y=b
    }
}