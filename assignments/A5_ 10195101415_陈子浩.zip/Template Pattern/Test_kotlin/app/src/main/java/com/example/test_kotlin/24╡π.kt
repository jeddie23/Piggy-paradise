package com.example.test_kotlin
var final:String=""
fun main()
{
    var array1 = arrayOf(1.0,5.0,5.0,5.0)
    math24(4,array1)
    print(final)
}

fun count(a:Array<String>,b: Int,c:Array<Double>)
{
    if(b==1)
    {
        if(c[0]==24.0)
        {
            final=a[0]+"=24"
        }
    }
    else if(b==4)
    {
        for(i in 0..2)
        {
            if(i==0)
            {
                for(j in 0..3)
                {
                    if(j==0)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]+c[1]
                        temp[1]=c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]+"+"+a[1]
                        temps[1]=a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==1)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]-c[1]
                        temp[1]=c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]+"-"+a[1]
                        temps[1]=a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==2)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]*c[1]
                        temp[1]=c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]+"*"+a[1]
                        temps[1]=a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==3)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]/c[1]
                        temp[1]=c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]+"/"+a[1]
                        temps[1]=a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                }
            }
            else if(i==1)
            {
                for(j in 0..3)
                {
                    if(j==0)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[2]+c[1]
                        temp[2]=c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]+"+"+a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==1)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]-c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]+"-"+a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==2)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[2]*c[1]
                        temp[2]=c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]+"*"+a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                    else if(j==3)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]/c[2]
                        temp[2]=c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]+"/"+a[2]
                        temps[2]=a[3]
                        count(temps,3,temp)
                    }
                }
            }
            else if(i==2)
            {
                for(j in 0..3)
                {
                    if(j==0)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]
                        temp[2]=c[2]+c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]
                        temps[2]=a[2]+"+"+a[3]
                        count(temps,3,temp)
                    }
                    else if(j==1)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]
                        temp[2]=c[2]-c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]
                        temps[2]=a[2]+"-"+a[3]
                        count(temps,3,temp)
                    }
                    else if(j==2)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]
                        temp[2]=c[2]*c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]
                        temps[2]=a[2]+"*"+a[3]
                        count(temps,3,temp)
                    }
                    else if(j==3)
                    {
                        var temps=arrayOf("","","")
                        var temp=arrayOf(0.0,0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]
                        temp[2]=c[2]/c[3]
                        temps[0]=a[0]
                        temps[1]=a[1]
                        temps[2]=a[2]+"/"+a[3]
                        count(temps,3,temp)
                    }
                }
            }
        }
    }
    else if(b==3)
    {
        for(i in 0..1)
        {
            if(i==0)
            {
                for(j in 0..3)
                {
                    if(j==0)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]+c[1]
                        temp[1]=c[2]
                        temps[0]=a[0]+"+"+a[1]
                        temps[1]=a[2]
                        count(temps,2,temp)
                    }
                    else if(j==1)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]-c[1]
                        temp[1]=c[2]
                        if(a[1].count()>=3)
                        {
                            temps[0] = a[0] + "-(" + a[1]+")"
                        }
                        else
                        {
                            temps[0] = a[0] + "-" + a[1]
                        }
                        temps[1]=a[2]
                        count(temps,2,temp)
                    }
                    else if(j==2)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]*c[1]
                        temp[1]=c[2]
                        if(a[0].count()>2)
                        {
                            temps[0]="("+a[0]+")"
                        }
                        else
                        {
                            temps[0] = a[0]
                        }
                        temps[0]=temps[0]+"*"
                        if(a[1].count()>2)
                        {
                            temps[0]=temps[0]+"("+a[1]+")"
                        }
                        else
                        {
                            temps[0]=temps[0]+a[1]
                        }
                        temps[1]=a[2]
                        count(temps,2,temp)
                    }
                    else if(j==3)
                    {
                        if(c[1]!=0.0)
                        {
                            var temps = arrayOf("", "")
                            var temp = arrayOf(0.0, 0.0)
                            temp[0] = c[0] / c[1]
                            temp[1] = c[2]
                            if(a[0].count()>2)
                            {
                                temps[0]="("+a[0]+")"
                            }
                            else
                            {
                                temps[0] = a[0]
                            }
                            temps[0]=temps[0]+"/"
                            if(a[1].count()>2)
                            {
                                temps[0]=temps[0]+"("+a[1]+")"
                            }
                            else
                            {
                                temps[0]=temps[0]+a[1]
                            }
                            temps[1] = a[2]
                            count(temps, 2, temp)
                        }
                    }
                }
            }
            else if(i==1)
            {
                for(j in 0..3)
                {
                    if(j==0)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]+c[2]
                        temps[0]=a[0]
                        temps[1]=a[1]+"+"+a[2]
                        count(temps,2,temp)
                    }
                    else if(j==1)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]-c[2]
                        temps[0]=a[0]
                        if(a[2].count()>=3) {
                            temps[1] = a[1] + "-(" + a[2]+")"
                        }
                        else
                        {
                            temps[1] = a[1] + "-" + a[2]
                        }
                        count(temps,2,temp)
                    }
                    else if(j==2)
                    {
                        var temps=arrayOf("","")
                        var temp=arrayOf(0.0,0.0)
                        temp[0]=c[0]
                        temp[1]=c[1]*c[2]
                        if(a[1].count()>2)
                        {
                            temps[1]="("+a[1]+")"
                        }
                        else
                        {
                            temps[1] = a[1]
                        }
                        temps[1]=temps[1]+"*"
                        if(a[2].count()>2)
                        {
                            temps[1]=temps[1]+"("+a[2]+")"
                        }
                        else
                        {
                            temps[1]=temps[1]+a[2]
                        }
                        temps[0]=a[0]
                        count(temps,2,temp)
                    }
                    else if(j==3)
                    {
                        if(c[2]!=0.0)
                        {
                            var temps = arrayOf("", "")
                            var temp = arrayOf(0.0, 0.0)
                            temp[0] = c[0]
                            temp[1] = c[1]/c[2]
                            if(a[1].count()>2)
                            {
                                temps[1]="("+a[1]+")"
                            }
                            else
                            {
                                temps[1] = a[1]
                            }
                            temps[1]=temps[1]+"/"
                            if(a[2].count()>2)
                            {
                                temps[1]=temps[1]+"("+a[2]+")"
                            }
                            else
                            {
                                temps[1]=temps[1]+a[2]
                            }
                            temps[0] = a[0]
                            count(temps, 2, temp)
                        }
                    }
                }
            }
        }
    }
    else if(b==2)
    {
        for(i in 0..3)
        {
            if(i==0)
            {
                var temps=arrayOf("")
                var temp=arrayOf(0.0)
                temp[0]=c[0]+c[1]
                temps[0]=a[0]+"+"+a[1]
                count(temps,1,temp)
            }
            else if(i==1)
            {
                var temps=arrayOf("")
                var temp=arrayOf(0.0)
                temp[0]=c[0]-c[1]
                if(a[1].count()>=3) {
                    temps[0] = a[0] + "-(" + a[1]+")"
                }
                else
                {
                    temps[0] = a[0] + "-" + a[1]
                }
                count(temps,1,temp)
            }
            else if(i==2)
            {
                var temps=arrayOf("")
                var temp=arrayOf(0.0)
                temp[0]=c[0]*c[1]
                if(a[0].count()>2)
                {
                    temps[0]="("+a[0]+")"
                }
                else
                {
                    temps[0] = a[0]
                }
                temps[0]=temps[0]+"*"
                if(a[1].count()>2)
                {
                    temps[0]=temps[0]+"("+a[1]+")"
                }
                else
                {
                    temps[0]=temps[0]+a[1]
                }
                count(temps,1,temp)
            }
            else if(i==3)
            {
                if(c[1]!=0.0)
                {
                    var temps = arrayOf("")
                    var temp = arrayOf(0.0)
                    temp[0] = c[0] / c[1]
                    if(a[0].count()>2)
                    {
                        temps[0]="("+a[0]+")"
                    }
                    else
                    {
                        temps[0] = a[0]
                    }
                    temps[0]=temps[0]+"/"
                    if(a[1].count()>2)
                    {
                        temps[0]=temps[0]+"("+a[1]+")"
                    }
                    else
                    {
                        temps[0]=temps[0]+a[1]
                    }
                    count(temps, 1, temp)
                }
            }
        }
    }
}

fun math24(b: Int,c: Array<Double>)
{
        for (i in 0..3) {
            for (j in 0..2) {
                for (k in 0..1) {
                    var temp = arrayOf(0.0, 0.0, 0.0, 0.0)
                    var ii = i
                    var jj = j
                    var kk = k
                    if (ii <= jj) {
                        jj = jj + 1
                    }
                    temp[0] = c[ii]
                    temp[1] = c[jj]
                    var up = 0
                    for (z in 0..3) {
                        if ((z != ii) && (z != jj)) {
                            if (up == 0) {
                                if (kk == 0) {
                                    temp[2] = c[z]
                                    up = 1
                                } else {
                                    temp[3] = c[z]
                                    up = 1
                                }
                            } else {
                                if (kk == 0) {
                                    temp[3] = c[z]
                                    up = 1
                                } else {
                                    temp[2] = c[z]
                                    up = 1
                                }
                                break
                            }
                        }
                    }
                    var a=arrayOf("","","","")
                    for(p in 0..3)
                    {
                        a[p]=temp[p].toInt().toString()
                    }
                    count(a, b, temp)
                }
            }
        }
}