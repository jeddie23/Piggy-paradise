package com.example.test_kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView

class Activity2 : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
        val button3:Button=findViewById(R.id.button3)
        button3.setOnClickListener(this)
        val button2:Button=findViewById(R.id.button2)
        button2.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        val num1: EditText=findViewById(R.id.editTextNumber)
        val num2: EditText=findViewById(R.id.editTextNumber2)
        val num3: EditText=findViewById(R.id.editTextNumber3)
        val num4: EditText=findViewById(R.id.editTextNumber4)
        when(v?.id){
            R.id.button3->{
                try {
                    var n1 = num1.text.toString().toDouble()
                    var n2 = num2.text.toString().toDouble()
                    var n3 = num3.text.toString().toDouble()
                    var n4 = num4.text.toString().toDouble()
                    var arrays = arrayOf(n1, n2, n3, n4)
                    math24(4, arrays)
                    if (final.length == 0) {
                        final = "无解"
                    }
                    val text1: TextView = findViewById(R.id.textView1)
                    text1.setText(final)
                    final = ""
                }
                catch(e:Exception)
                {
                    val text1: TextView = findViewById(R.id.textView1)
                    text1.setText("输入错误")
                }
            }
            R.id.button2->{
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}